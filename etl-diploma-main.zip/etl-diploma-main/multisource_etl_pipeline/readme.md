# ETL Pipeline в Apache Airflow с использованием нескольких источников


